import 'package:cookbooksamples/Helpers/ServiceResult.dart';

/* Create a IPlatformSharedPreferenceService as abstract class */
abstract class IPlatformSharedPreferenceService {

  // Create a method to save data in shared preference
  Future<ServiceResult<bool>> saveData<T>({required String key, required T value});

  // Create a method to retrive the data from shared preference
  Future<ServiceResult<T?>> retriveData<T>({required String key});

  // Create a method to delete the data in shared preference
  Future<ServiceResult<bool>> deleteData({required String key});

}
