import 'dart:convert';
import 'package:cookbooksamples/Helpers/ServiceResult.dart';
import 'package:cookbooksamples/Helpers/Utitilites/Utilities.dart';
import 'package:cookbooksamples/Services/PlatformServices/PlatformSharedPreferenceService/IPlatformSharedPreferenceService.dart';
import 'package:dart_json_mapper/dart_json_mapper.dart';
import 'package:shared_preferences/shared_preferences.dart';

/* Create a PlatformSharedPreferenceService that extends the interface */
class PlatformSharedPreferenceService extends IPlatformSharedPreferenceService {

  @override

  /* Create a method saveData() to store the data in shared preference and pass the key and value as parameter */
  Future<ServiceResult<bool>> saveData<T>(
      {required String key, required T value}) async {
    try {
      // Create a map 'userInfo' and store the value against key key
      Map<String, dynamic> userInfo = {
        key: value,
      };

      // Serialize the userInfo and store the result in a 'encodedData' variable
      String encodedData = JsonMapper.serialize(userInfo);

      // Set the encodedData in sharedPreferences against the key using setString().
      bool result = await SharedPreferences.getInstance().then((value) => value.setString(key,encodedData));

      // Check, if the result is equals true
      return result == true
          ?
          // Return true
          ServiceResult(statusCode: ServiceStatusCode.OK, content: result)
          :

          // Return false
          ServiceResult(
              statusCode: ServiceStatusCode.SystemException, content: false);
    } catch (e) {
      
      // Invoke writeExceptionData()
      e.writeExceptionData();

      // Return false
      return ServiceResult(
          statusCode: ServiceStatusCode.SystemException, content: false);
    }
  }

  @override

  /* Create a method retriveData() to retrive the data and pass the key as parameter*/
  Future<ServiceResult<T?>> retriveData<T>({required String key}) async {
    try {
      // Retrieve the data by passing key to getString() and store the result in retrivedData
      String retrivedData = await SharedPreferences.getInstance().then((value) => value.getString(key) ?? "");

      // Deserialize the retrivedData and store it decodedData variable
      // var a = retrivedData.runtimeType;
      var decodedData =
          JsonMapper.deserialize<T>(json.decode(retrivedData)?["data"]);

      // Check, if the decodedData not equals to null
      return decodedData != null
          ?
          // If yes, Return the decodedData
          ServiceResult(statusCode: ServiceStatusCode.OK, content: decodedData)
          :

          // If no, Return null.
          ServiceResult(statusCode: ServiceStatusCode.NoContent, content: null);
    } catch (e) {
      
      // Invoke writeExceptionData()
      e.writeExceptionData();

      // Return null.
      return ServiceResult(
          statusCode: ServiceStatusCode.SystemException, content: null);
    }
  }


  

  @override

   /* Create a method deleteData() to delete the data and pass the key as parameter*/
  Future<ServiceResult<bool>> deleteData({required String key}) async {
    try {

      // Delete the data by passing key to remove() and store result in 'result' variable
      bool result = await SharedPreferences.getInstance().then((value) => value.remove(key));

      
      return result
          ? 

          // Return true
          ServiceResult(statusCode: ServiceStatusCode.OK, content: result)
          : 
          
          // Return false
          ServiceResult(
              statusCode: ServiceStatusCode.SystemException, content: result);
    } catch (e) {

      // Invoke writeExceptionData()
      e.writeExceptionData();

      // Return false
      return ServiceResult(
          statusCode: ServiceStatusCode.SystemException, content: false);
    }
  }
}
